#!/bin/bash

LOGFILE="/var/log/miner_script.log"
WORK_DIR=$(pwd)

if pgrep -x "monitor.sh" >/dev/null; then
    echo "$(date +"%Y-%m-%d %H:%M:%S")     INFO Another instance of monitor.sh is already running. Exiting..."
else
    source /etc/profile; nohup $WORK_DIR/monitor.sh  >> $WORK_DIR/.monitor.sh 2>&1 &
fi

[ -t 1 ] && . colors

CUSTOM_TEMPLATE=$(grep 'CUSTOM_TEMPLATE' /hive-config/wallet.conf | awk -F '=' '{print $2}' | tr -d '"')
echo "Sub-accounts are: $CUSTOM_TEMPLATE" >> $LOGFILE

update_wallet_conf() {
    sed -i 's|qubic2.hk.apool.io:3334|aleo1.hk.apool.io|' /hive-config/wallet.conf
    sed -i 's/"coin":"QUBIC"/"coin":"ALEO"/' /hive-config/wallet.conf
}

revert_wallet_conf() {
    sed -i 's|aleo1.hk.apool.io|qubic2.hk.apool.io:3334|' /hive-config/wallet.conf
    sed -i 's/"coin":"ALEO"/"coin":"QUBIC"/' /hive-config/wallet.conf
}

source apoolminer_hiveos_qubic_aleo_idle_mining.conf
echo $PROXY >> $LOGFILE
source h-manifest.conf
echo $MINER_REST_PORT >> $LOGFILE
source "$CUSTOM_CONFIG_FILENAME"
export LD_LIBRARY_PATH=./:$LD_LIBRARY_PATH

HOSTNAME=$(hostname)
[[ -z $CUSTOM_LOG_BASENAME ]] && { echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}"; exit 1; }
[[ -z $CUSTOM_CONFIG_FILENAME ]] && { echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}"; exit 1; }
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && { echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}"; exit 1; }

CUSTOM_LOG_BASEDIR=$(dirname "${CUSTOM_LOG_BASENAME}")
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p "$CUSTOM_LOG_BASEDIR"

while true; do
    response=$(curl -s http://qubic1.hk.apool.io:8001/api/qubic/epoch_challenge | grep -o '"mining_seed":"[^"]*"' | sed 's/.*"mining_seed":"\([^"]*\)".*/\1/')
    echo "$(date) - Detected Response：$response" >> $LOGFILE

    if [ "$response" == "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=" ]; then
        echo "$(date) - Correct response. Update wallet.conf 为 ALEO。" >> $LOGFILE
        update_wallet_conf
        echo "$(date) - Restart the miner..." >> $LOGFILE

        echo "$(date) - start ALEO miner" >> $LOGFILE
            ./aleo_prover --address aleo1t7ujjtcykw3t5j4mm90h44glsycddkffctanjutd79r96y3m95pqqh0t8n --pool aleo.asia1.zk.work:10003 --pool aleo.hk.zk.work:10003 --pool aleo.jp.zk.work:10003 $CUSTOM_USER_CONFIG 2>&1 | tee ${CUSTOM_LOG_BASENAME}.log
    else
        echo "$(date) - Keep or restore to QUBIC。" >> $LOGFILE
        revert_wallet_conf

        if ! pgrep -f 'apoolminer.*account'; then
            echo "Running $NVTOOL" | tee -a ${CUSTOM_LOG_BASENAME}.log
            echo "$(date) - Launch QUBIC Miner" >> $LOGFILE
            ./apoolminer --account "$CUSTOM_TEMPLATE" --pool $PROXY --rest --port "$MINER_REST_PORT" -A qubic $EXTRA 2>&1 | tee --append "${CUSTOM_LOG_BASENAME}.log"
        fi
    fi

    echo "$(date) - The cycle ends and waits for the next detection..." >> $LOGFILE
done
